<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ApplicationController;
use App\Http\Controllers\Api\ManagerApplicationController;
use App\Http\Controllers\Api\Admin\DashboardController;
use App\Http\Controllers\Api\Admin\ServiceApplicationController;
use App\Http\Controllers\Api\Admin\ServiceFormController;
use App\Http\Controllers\Api\Admin\ServiceFormFieldController;
use App\Http\Controllers\Api\Admin\ServiceFormFieldConditionController;
use App\Http\Controllers\Api\Admin\ServiceFormSectionController;
use App\Http\Controllers\Api\Admin\ServiceFormStepController;
use App\Http\Controllers\Api\Admin\ApplicationDashboardController;
use App\Http\Controllers\Api\Admin\ReportingDashboardController;
use App\Http\Controllers\Api\Customer\CustomerServiceApplicationController;
use App\Http\Controllers\Api\Customer\CustomerNotificationController;
use App\Http\Controllers\Api\OfficerApplicationShareController;
use App\Http\Controllers\Api\Public\PublicApplicationController;
use App\Http\Controllers\Api\Public\ApplicationTrackingController;
use App\Http\Controllers\Api\Officer\OfficerApplicationController;
use App\Http\Controllers\Api\Officer\CertificateController;
use App\Http\Controllers\Api\FeedbackController;
use App\Http\Controllers\Api\WindowController;
use App\Http\Controllers\Api\NewsController;

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/applications', [ApplicationController::class, 'index']);
    Route::post('/applications', [ApplicationController::class, 'store']);
    Route::get('/applications/{application}', [ApplicationController::class, 'show']);
    Route::put('/applications/{application}', [ApplicationController::class, 'update']);
    Route::delete('/applications/{application}', [ApplicationController::class, 'destroy']);
    Route::get('/customer/notifications', [CustomerNotificationController::class, 'index']);
    Route::get('/customer/service-applications', [CustomerServiceApplicationController::class, 'index']);
    Route::get('/customer/service-applications/{application}', [CustomerServiceApplicationController::class, 'show']);
});

Route::middleware('auth:sanctum')->prefix('admin')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::apiResource('service-forms', ServiceFormController::class);
    Route::apiResource('service-form-sections', ServiceFormSectionController::class);
    Route::apiResource('service-form-steps', ServiceFormStepController::class);
    Route::apiResource('service-form-fields', ServiceFormFieldController::class);
    Route::apiResource('service-form-field-conditions', ServiceFormFieldConditionController::class);
    Route::get('/service-applications', [ServiceApplicationController::class, 'index']);
    Route::get('/service-applications/{serviceApplication}', [ServiceApplicationController::class, 'show']);
    Route::put('/service-applications/{serviceApplication}', [ServiceApplicationController::class, 'update']);
    Route::delete('/service-applications/{serviceApplication}', [ServiceApplicationController::class, 'destroy']);
    Route::get('/applications/summary', [ApplicationDashboardController::class, 'summary']);
    Route::get('/dashboard/reporting', [ReportingDashboardController::class, 'index']);
    Route::get('/dashboard/reporting/report', [ReportingDashboardController::class, 'report']);


    Route::prefix('news')->group(function () {
        Route::get('/', [NewsController::class, 'index']);
        Route::post('/', [NewsController::class, 'store']);
        Route::get('{news}', [NewsController::class, 'show']);
        Route::put('{news}', [NewsController::class, 'update']);
        Route::patch('{news}', [NewsController::class, 'update']);
        Route::delete('{news}', [NewsController::class, 'destroy']);
    });


});

Route::prefix('public')->group(function () {
    Route::get('/services/{service}/form', [PublicApplicationController::class, 'form']);
    Route::middleware('auth:sanctum')->post('/services/{service}/apply', [PublicApplicationController::class, 'apply']);
    Route::post('/track-application', [ApplicationTrackingController::class, 'track']);
});

Route::middleware('auth:sanctum')->prefix('officer')->group(function () {
    Route::get('/applications/queue', [OfficerApplicationController::class, 'queue']);
    Route::get('/notifications', [OfficerApplicationController::class, 'notifications']);
    Route::get('/applications/{application}', [OfficerApplicationController::class, 'show']);
    Route::get('/sharing/windows', [OfficerApplicationShareController::class, 'windows']);
    Route::get('/sharing/windows/{window}/officers', [OfficerApplicationShareController::class, 'officers']);
    Route::post('/applications/{application}/share-to-officer', [OfficerApplicationShareController::class, 'share']);
    Route::post('/applications/{application}/accept', [OfficerApplicationController::class, 'accept']);
    Route::post('/applications/{application}/appointment', [OfficerApplicationController::class, 'appointment']);
    Route::post('/applications/{application}/share', [OfficerApplicationController::class, 'share']);
    Route::post('/applications/{application}/forward-to-back-officer', [OfficerApplicationController::class, 'forwardToBackOfficer']);
    Route::post('/applications/{application}/approve', [OfficerApplicationController::class, 'approve']);
    Route::post('/applications/{application}/reject', [OfficerApplicationController::class, 'reject']);
    Route::post('/applications/{application}/return', [OfficerApplicationController::class, 'returnApplication']);
    Route::post('/applications/{application}/complete', [OfficerApplicationController::class, 'complete']);
    Route::post('/applications/{application}/escalate-to-manager', [OfficerApplicationController::class, 'escalateToManager']);
    Route::get('/applications/{application}/certificate', [CertificateController::class, 'download']);
});

Route::middleware('auth:sanctum')->prefix('manager')->group(function () {
    Route::get('/applications/queue', [ManagerApplicationController::class, 'queue']);
    Route::get('/applications/{application}', [ManagerApplicationController::class, 'show']);
    Route::post('/applications/{application}/assign-officer', [ManagerApplicationController::class, 'assign']);
    Route::post('/applications/{application}/return-to-officer', [ManagerApplicationController::class, 'returnToOfficer']);
    Route::post('/applications/{application}/escalate-up', [ManagerApplicationController::class, 'escalateUp']);
});


// Public kiosk submission — no login required at the service window.
Route::post('feedback', [FeedbackController::class, 'store']);

// Viewing / managing feedback requires an authenticated agent so it can be
// scoped to their city / subcity / woreda.
Route::middleware('auth:sanctum')->group(function () {
    Route::get('feedback', [FeedbackController::class, 'index']);
    // Must be registered before feedback/{feedback} so "windows" isn't
    // captured as a feedback ID.
    Route::get('feedback/windows', [FeedbackController::class, 'windows']);
    Route::get('feedback/{feedback}', [FeedbackController::class, 'show']);
    Route::put('feedback/{feedback}', [FeedbackController::class, 'update']);
    Route::patch('feedback/{feedback}', [FeedbackController::class, 'update']);
    Route::delete('feedback/{feedback}', [FeedbackController::class, 'destroy']);
});

Route::get(
    'windows/{window}/services',
    [WindowController::class, 'services']
);
